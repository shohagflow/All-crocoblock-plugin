<?php
/**
 * Compare & Wishlist Assets class
 */

defined( 'ABSPATH' ) || exit; // Exit if accessed directly.

if ( ! class_exists( 'Jet_CW_Assets' ) ) {

	class Jet_CW_Assets {

		public function __construct() {
			add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_styles' ] );
		}

		/**
		 * Enqueue public-facing stylesheets.
		 *
		 * @since  1.0.0
		 */
		public function enqueue_styles() {

			wp_enqueue_style(
				'jet-cw',
				jet_cw()->plugin_url( 'assets/css/jet-cw.css' ),
				false,
				jet_cw()->get_version()
			);

			wp_enqueue_style(
				'jet-cw-frontend',
				jet_cw()->plugin_url( 'assets/css/lib/jet-cw-frontend-font/css/jet-cw-frontend-font.css' ),
				false,
				jet_cw()->get_version()
			);

		}

	}

}