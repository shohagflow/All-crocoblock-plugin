<?php
/**
 * Checkout Coupon Form Template
 */

woocommerce_checkout_coupon_form();

