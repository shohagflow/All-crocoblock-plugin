<?php
/**
 * JetWooBuilder Single Related Posts output.
 */

woocommerce_output_related_products();
