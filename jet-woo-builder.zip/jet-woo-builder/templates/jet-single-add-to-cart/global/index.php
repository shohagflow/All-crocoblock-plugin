<?php
/**
 * JetWooBuilder Single Add to Cart template.
 */

woocommerce_template_single_add_to_cart();
