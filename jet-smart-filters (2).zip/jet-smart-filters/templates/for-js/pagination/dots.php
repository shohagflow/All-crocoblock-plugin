<?php
/**
 * Pagination dots template
 */

?>
<div class="jet-filters-pagination__dots">&hellip;</div>