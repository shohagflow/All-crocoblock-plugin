<?php return array('dependencies' => array('react'), 'version' => 'c119a26de597092ff5f0');
